import pyperclip

pyperclip.copy('''
def main():
    pass

if __name__ == '__main__':
    main()''')

print(f'newpy copied to clipboard.')