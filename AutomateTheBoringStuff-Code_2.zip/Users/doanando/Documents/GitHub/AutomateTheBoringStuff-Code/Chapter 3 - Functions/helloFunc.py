# Write your code here :-)

def hello():
    print('Howdy partner!')
    print('Howdy!!!!')
    print('Hello there.')


hello()
hello()
hello()
