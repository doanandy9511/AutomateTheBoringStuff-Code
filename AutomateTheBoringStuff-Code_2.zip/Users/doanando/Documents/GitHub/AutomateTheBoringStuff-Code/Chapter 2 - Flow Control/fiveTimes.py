# Write your code here :-)
print('My name is')
for i in range(5):
    print('Jimmy Five Times ({0})'.format(i))

sum = 0
for num in range(101):
    sum += num
print(sum)

for i in range(12,16):
    print(i)

for i in range(0,10,2):
    print(i)
