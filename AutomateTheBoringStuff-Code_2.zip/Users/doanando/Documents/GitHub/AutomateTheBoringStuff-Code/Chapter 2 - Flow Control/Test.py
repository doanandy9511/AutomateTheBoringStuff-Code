
print("lmao")