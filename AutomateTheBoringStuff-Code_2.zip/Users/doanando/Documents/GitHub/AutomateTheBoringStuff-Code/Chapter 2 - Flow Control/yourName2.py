# Write your code here :-)
while True:
    print('Please type your name')
    name = input()
    if name == "your name":
        break
print('Thanks bruh')

# infinite loop
# press ctrl+c to break out
while True:
    print('Reee')
