# Write your code here :-)
def hello(name):
    print('Hello, {0}'.format(name))

hello('Alice')
hello('Bob')
